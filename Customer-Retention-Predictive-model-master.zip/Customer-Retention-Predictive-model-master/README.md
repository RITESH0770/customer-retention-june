# Customer-Retention-Predictive-model
Predict behavior to retain customers. You can analyze all relevant customer data and develop focused customer retention programs.
